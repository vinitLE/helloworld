VanillaTilt.init(document.querySelector("#img11"), {
    max: 25,
    speed: 400,
    glare: true,
    "max-glare":1
});
VanillaTilt.init(document.querySelector("#img12"), {
    max: 25,
    speed: 400,
    glare: true,
    "max-glare":1
});

